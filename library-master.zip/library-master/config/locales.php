<?php

return [
    'en', 'ru', 'kz'
];
