<?php

namespace App\Http\Controllers\Api\Cataloging;

use App\Common\Fields\Cataloging\MediaFields;
use App\Common\Helpers\Show\SearchFields;
use App\Http\Controllers\Api\Cataloging\Handler\MarcFieldsHandler;
use App\Http\Controllers\Api\Cataloging\Handler\MarcFieldsXmlHandler;
use App\Http\Controllers\Controller;
use App\Models\Media\MaterialTypeFactory;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class ShowController extends Controller
{
    public function getMaterialById(string $type, int $materialId): JsonResponse
    {
        $keyName = explode('.', MaterialTypeFactory::getMaterialClass($type)->getKeyName());

        $marcData = DB::table('view_marc_data')->select()->where($keyName[1] ?? $keyName[0], $materialId)->orderBy('id')->get()->toArray();

        if ($type === 'BK') {
            $actualData = DB::table('lib_books as b')
                ->select(
                    'b.isbn', 'b.title', 'p.name as publisher', 'b.pub_year', 'b.pub_city',
                    'b.parallel_title', 'b.title_related_info', 'b.language',
                    DB::raw("(select listagg(a.name||''||a.surname, ',')
                                within group(order by a.name||''||a.surname)
                                from lib_book_authors a where a.book_id = b.book_id and a.is_main = 1) as main_author"),
                    'b.page_num'
                )
                ->leftJoin('lib_publishers as p', 'p.publisher_id', '=', 'b.publisher_id')
                ->where('b.book_id', $materialId)
                ->first();
        }

        $result = MarcFieldsHandler::generateArray($marcData, $actualData ?? []);

        return response()->json([
            'res' => $result
        ]);
    }

    public function getTypes(): JsonResponse
    {
        return response()->json([
            'res' => DB::table('lib_material_types')
                ->select('key as type', 'title_' . app()->getLocale() . ' as type_title')
                ->get()->toArray(),
        ]);
    }

    public function searchFields(): JsonResponse
    {
        return response()->json([
            'res' => SearchFields::searchFields(new MediaFields())
        ]);
    }

    public function exportXml(string $type, int $materialId): BinaryFileResponse
    {
        $keyName = explode('.', MaterialTypeFactory::getMaterialClass($type)->getKeyName());

        $marcData = DB::table('view_marc_data')->select()->where($keyName[1] ?? $keyName[0], $materialId)->orderBy('id')->get()->toArray();
        $template = (new MarcFieldsHandler([], $marcData))->getTemplate();
        $xml = (new MarcFieldsXmlHandler($template))->getXml();

        File::put(storage_path('') . "/material_{$materialId}.xml", $xml);

        return response()->download(storage_path('') . "/material_{$materialId}.xml");
    }
}
