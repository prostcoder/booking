<?php


namespace App\Models\User;


interface UserCidAttribute
{
    public function getUserCidAttribute();
}
