<?php


namespace App\Common\Interfaces\Models;


interface GetModelsInterface
{
    public static function getModels(): array;
}
