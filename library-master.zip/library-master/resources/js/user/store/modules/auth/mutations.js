export default{
	setUser(state,data){
		state.user=data;
	}
}