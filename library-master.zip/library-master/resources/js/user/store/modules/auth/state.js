export default{
	user:null
}