export default{
	loading:false
}