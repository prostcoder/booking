export default{
	setFullPageLoading(state,data){
		state.loading=data;
	}
}