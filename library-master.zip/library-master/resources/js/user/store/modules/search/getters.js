export default{
	request:state=>state.request,
	search_request:state=>state.search_request,
	query:state=>state.query,
	searching:state=>state.searching,
	results:state=>state.results,
	all_results:state=>state.all_results,
	filter_data:state=>state.filter_data,
	filter_search:state=>state.filter_search,
	wrapper_index:state=>state.wrapper_index,
	selected:state=>state.selected
}