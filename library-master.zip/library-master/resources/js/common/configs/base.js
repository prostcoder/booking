export default {
    baseURL: 'https://library.sdu.edu.kz/',
    api: 'api/',
    default_lang: 'en'
}