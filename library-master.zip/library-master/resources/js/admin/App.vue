<template>
    <main-body/>
</template>
<script>
import MainBody from './views/__main__'
import setLocale from './mixins/setLocale'
import {setTheme} from './mixins/settings'
export default {
    components:{
        MainBody
    },
    mixins:[setLocale,setTheme],
    methods:{
        getAuth(){
            // checks if the user is logined
            this.$http.get('/user').then(response => {
                this.$store.commit('setUser',response.data.res.user);
            }).catch(e=>{});
        },
        setGlobalLocale(){
            this.setLocale(JSON.parse(localStorage.getItem('lang')));
        }
    },
    created(){
        this.getAuth();
        this.setGlobalLocale();
    },
    mounted(){
        this.setTheme(localStorage.getItem('theme'));
    }
}
</script>
<style scoped>
@import '../common/assets/styles/colors.css';
@import '../common/assets/styles/common.css';
@import '../common/assets/styles/font.css';
@import '../common/assets/styles/sizes.css';
@import './assets/styles/style.css';
</style>