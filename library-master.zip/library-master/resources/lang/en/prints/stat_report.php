<?php

return [
    'year' => 'Year',
    'month' => 'Month',
    'total_borrow' => 'Total borrow',
    'on_hands' => 'On hands',
];
