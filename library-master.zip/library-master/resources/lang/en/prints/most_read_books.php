<?php

return [
    'author' => 'Author(s)',
    'title' => 'Title',
    'language' => 'Language',
    'isbn' => 'ISBN',
    'count_issue' => 'Count issue',
];
