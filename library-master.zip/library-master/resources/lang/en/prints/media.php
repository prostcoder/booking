<?php

return [
    'author' => 'Author(s)',
    'type' => 'Type',
    'title' => 'Title',
    'publisher' => 'Publisher',
    'isbn' => 'ISBN',
    'call_number' => 'Call number',
    'url' => 'URL to description'
];
