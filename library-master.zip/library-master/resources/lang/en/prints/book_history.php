<?php

return [
    'barcode' => 'Barcode',
    'inventory_no' => 'Inventory No',
    'type' => 'Type',
    'title' => 'Title',
    'author' => 'Author',
    'borrow_date' => 'Borrowed date',
    'due_date' => 'Due date',
    'delivery_date' => 'Delivery date',
    'status' => 'Status',
    'username' => 'Borrowed last user',
];
